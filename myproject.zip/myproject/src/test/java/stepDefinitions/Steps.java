package stepDefinitions;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.Assert;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import cucumber.api.java.en.Then;
import PageObjects.SummaryTab;


public class Steps extends BaseClass {

    @Before
    public void setup() throws IOException {
        //Logger
        logger = Logger.getLogger("NextGen"); //Added logger
        PropertyConfigurator.configure("Log4j.properties");//Added logger

        //Reading properties
        configProp = new Properties();
        FileInputStream configPropfile = new FileInputStream("config.properties");
        configProp.load(configPropfile);

        String br = configProp.getProperty("browser");

        if (br.equals("chrome")) {
            System.setProperty("webdriver.chrome.driver", configProp.getProperty("chromepath"));
            driver = new ChromeDriver();
        } else if (br.equals("firefox")) {
            System.setProperty("webdriver.gecko.driver", configProp.getProperty("firefoxpath"));
            driver = new FirefoxDriver();
        } else if (br.equals("ie")) {
            System.setProperty("webdriver.ie.driver", configProp.getProperty("iepath"));
            driver = new InternetExplorerDriver();
        }

        logger.info("******** Launching browser*********");
    }


    @Given("User Launch Chrome browser")
    public void user_Launch_Chrome_browser() {

        lp = new SummaryTab(driver);
    }

    @When("User opens URL {string}")
    public void user_opens_URL(String url) {
        logger.info("******** Opening URL*********");
        driver.get(url);
        driver.manage().window().maximize();
    }

    @And("User enters text as {string}")
    public void user_enters_text_as(String text) {
        logger.info("******** Providing login details*********");
        lp.setTxtsearch(text);


    }


    }

