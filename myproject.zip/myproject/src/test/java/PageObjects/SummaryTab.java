package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SummaryTab {

    public WebDriver ldriver;
    public SummaryTab(WebDriver rdriver) {
        ldriver = rdriver;
        PageFactory.initElements(rdriver, this);
}
    @FindBy(xpath = "//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input")
    @CacheLookup
    WebElement txtsearch;

    public void setTxtsearch(String text ) {
        txtsearch.clear();
        txtsearch.sendKeys(text);

    }



    }