package Runnner;

import org.junit.runner.RunWith;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
        strict = true,
        monochrome = true,
        features = "src/Resource",
        glue = "",
        plugin = {"pretty", "html:test-output" ,"json:target/Destination/cucumber.json"})
       
public class Runner {
}
